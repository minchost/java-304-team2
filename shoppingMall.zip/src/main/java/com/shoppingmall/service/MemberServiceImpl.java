package com.shoppingmall.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shoppingmall.domain.MemberVO;
import com.shoppingmall.mapper.MemberMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service 
@AllArgsConstructor
public class MemberServiceImpl implements MemberService{

	
	private MemberMapper mapper;	
									
	@Override
	public void register(MemberVO member) {
		mapper.insert(member);
		
	}

	@Override
	public MemberVO get(String member_id) {
		
		return mapper.read(member_id);
		
	}

	@Override
	public boolean modify(MemberVO member) {
		
		return mapper.update(member) == 1;
	}

	@Override
	public boolean remove(MemberVO member) {
		
		return mapper.delete(member) == 1;
	}

	@Override
	public List<MemberVO> getList() {
		
		return mapper.getList();
	}

	
	
}
