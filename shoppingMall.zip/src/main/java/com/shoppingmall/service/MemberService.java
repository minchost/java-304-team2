package com.shoppingmall.service;

import java.util.List;

import com.shoppingmall.domain.MemberVO;






public interface MemberService {
	
	public List<MemberVO> getList();
	
	public void register(MemberVO member); //占쎄퉱嚥≪뮇�뒲 野껊슣�뻻�눧占� 占쎌삂占쎄쉐占쎌뒠
	
	public MemberVO get(String member_id); //bno 甕곕뜇�깈�몴占� 占쎌뵠占쎌뒠占쎈립 野껊슣�뻻�눧�눘�뱽 1椰꾨똻�뱽 揶쏉옙占쎌죬占쎌궔占쎈뼄.
	
	public boolean modify(MemberVO member);	//占쎈땾占쎌젟占쎌뒠
	
	public boolean remove(MemberVO member);	//野껊슣�뻻�눧占� 甕곕뜇�깈占쎌뵠占쎌뒠 占쎄텣占쎌젫
	
	
	
}
