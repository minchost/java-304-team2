package com.shoppingmall.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.shoppingmall.domain.CustomUser;
import com.shoppingmall.domain.MemberVO;
import com.shoppingmall.mapper.MemberMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class CustomUserDetailsService implements UserDetailsService{
	
	@Setter(onMethod_ = @Autowired )
	private MemberMapper memberMapper;
	
	@Override
	public UserDetails loadUserByUsername(String member_id) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		log.warn("Load User By member_name :" + member_id);
		
		MemberVO member = memberMapper.read(member_id);
		
		log.warn("queried by member mapper : " + member);
		
		
		return member == null ? null : new CustomUser(member);
	}
	
	
}
