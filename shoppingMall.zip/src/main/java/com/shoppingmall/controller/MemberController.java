package com.shoppingmall.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.shoppingmall.domain.MemberVO;
import com.shoppingmall.service.MemberService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
@RequestMapping("/member/*")
@AllArgsConstructor

public class MemberController {
	

	private MemberService  service;

	
	@GetMapping("/memberlist")
	public void list(Model model) {
	
		model.addAttribute("list", service.getList());
		
	}

	
	@GetMapping("/register")
	public void register() {
		
	}
	@PostMapping("/register")
	public String register(MemberVO member ) {
		service.register(member);
		
		return "redirect:../customLogin";
	}
	@GetMapping("/modify")
	public void modify(MemberVO member, Model model) {
		
		   
		 
		/*
		 * model.addAttribute("member", service.get(member.getMember_id()));
		 */
		 
	}
	@PostMapping("/modify")
	public String modify(MemberVO member) {
		
		service.modify(member);
		return "redirect:/member/list";
	}
	
}