package com.shoppingmall.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lombok.extern.log4j.Log4j2;

@Log4j2
@RequestMapping("/sample/*")
@Controller
public class SampleController {
	
	@GetMapping("/all")
	public void doAll() {
		log.info("���ΰ���");
	}
	@GetMapping("/member")
	public void doMember() {
		log.info("�ɹ��� ����");
	}
	@GetMapping("/admin")
	public void doAdmin() {
		log.info("�����ڸ�");
	}
	
	
}
