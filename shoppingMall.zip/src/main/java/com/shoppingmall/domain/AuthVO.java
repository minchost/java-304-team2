package com.shoppingmall.domain;

import lombok.Data;

@Data
public class AuthVO {
	private String member_id;
	private String auth;
}
