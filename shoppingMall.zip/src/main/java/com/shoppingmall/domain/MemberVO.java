package com.shoppingmall.domain;

import java.util.List;

import lombok.Data;

@Data
public class MemberVO {
	private String member_id;	
	private String member_pw;
	private String member_name;
	private String member_gen;
	private String member_tel;
	private String member_email;
	private String member_addr;
	
	private List<AuthVO> authList;
}
