<�Խ���>
create table board(
	bno number(10) primary key,
	title varchar2(200) not null,
	content varchar2(2000) not null,
	writer varchar2(50) not null,
	regdate date default sysdate,
	updatedate date default sysdate
);

게시물 번호
제목
내용
글쓴이
게시물 생성날짜
게시물 수정날짜

<회원가입>
create table member(
	member_id varchar2(20) primary key,	
	member_pw varchar2(20) not null,
	member_name varchar2(20) not null,
	member_gen varchar2(20) not null,
	member_tel varchar2(20) not null,
	member_email varchar2(30) not null,
	member_addr varchar2(200) not null
);
아이디
패스워드
이름
성별
전화번호
email
주소

create table board(
	bno number(10,0) primary key,
	title varchar2(200) not null,
	content varchar2(2000) not null,
	writer varchar2(50) not null,
	regdate date default sysdate,
	updatedate date default sysdate
);
CREATE SEQUENCE bno_seq
       INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       NOORDER;

create table goods(
	good_id number(20) primary key,
	good_sort varchar2(50) not null,
	good_name varchar2(50) not null,
	good_price number(10) not null,
	good_size varchar2(20) not null
);

CREATE SEQUENCE good_id_seq
       INCREMENT BY 1
       START WITH 1000
       MINVALUE 1
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       NOORDER;

create table member_auth(
	member_id varchar2(20) not null,	
	auth varchar2(50) not null,
	constraint fk_member_auth foreign key(member_id) references member(member_id)
	
);

       
insert into board (bno, title, content, writer)
values (bno_seq.nextval, '현아테스트', '현아테스트', '현아');

CREATE TABLE "T_SHOPPING_ORDER"
   (	"ORDER_SEQ_NUM" NUMBER(20) primary key,
	"ORDER_ID" NUMBER(20),
	"MEMBER_ID" VARCHAR2(20 BYTE),
	"GOODS_ID" NUMBER(20,0),
	"ORDERER_NAME" VARCHAR2(50 BYTE),
	"GOODS_TITLE" VARCHAR2(100 BYTE),
	"ORDER_GOODS_QTY" NUMBER(5,0),
	"RECEIVER_NAME" VARCHAR2(50 BYTE),
	"RECEIVER_HP1" VARCHAR2(20 BYTE),
	"RECEIVER_TEL1" VARCHAR2(20 BYTE),
	"DELIVERY_ADDRESS" VARCHAR2(500 BYTE),
	"PAY_METHOD" VARCHAR2(200 BYTE),
	"CARD_COM_NAME" VARCHAR2(50 BYTE),
	"CARD_PAY_MONTH" VARCHAR2(20 BYTE)
   ) ;

CREATE SEQUENCE order_seq_num_seq
       INCREMENT BY 1
       START WITH 1000
       MINVALUE 1
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       NOORDER;

SELECT * FROM user_tables;
select * from board;
select * from member;
select * from T_SHOPPING_ORDER;